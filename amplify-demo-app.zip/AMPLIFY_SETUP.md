# Amplify Hosting Setup

See amplify.yml for config.
