import React from 'react'

export default function App() {
  return (
    <div style={{padding:'2rem',fontFamily:'sans-serif',color:'#e2e8f0',background:'#0b1020',minHeight:'100vh'}}>
      <h1>Zazim AI Demo Dashboard</h1>
      <p>This is a starter demo app scaffold. Replace with map, panels, and mock data.</p>
    </div>
  )
}
